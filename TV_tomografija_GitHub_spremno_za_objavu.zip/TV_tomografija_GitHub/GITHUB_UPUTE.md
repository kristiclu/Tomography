# Objava projekta na GitHubu

## 1. Kreiraj repozitorij

Na [github.com/new](https://github.com/new) napravi novi repozitorij:

- **Repository name:** `TV-tomografija`
- **Description:** `Tomografska rekonstrukcija uz TV regularizaciju, Chambolle–Pockov algoritam i Morozovljevo pravilo diskrepancije.`
- **Visibility:** `Public` ako je dopuštena javna objava projektnog rada i priloženih slika; inače `Private`.
- **Nemoj** automatski dodavati README ni `.gitignore` jer već postoje u pripremljenoj mapi.

## 2. Pokreni Git naredbe

U terminalu otvori ovu raspakiranu mapu (onu koja sadrži `README.md`) i pokreni:

```bash
git init
git add .
git commit -m "Add TV tomography project with Morozov parameter selection"
git branch -M main
git remote add origin https://github.com/TVOJE-KORISNICKO-IME/TV-tomografija.git
git push -u origin main
```

Zamijeni `TVOJE-KORISNICKO-IME` svojim GitHub korisničkim imenom. Pri prvom pushu GitHub može zatražiti autentifikaciju.

Ako si već otvorila repozitorij s postojećim datotekama, provjeri njegov sadržaj prije ovih naredbi; nema potrebe ponovno pokretati `git init`.

## 3. Predložene teme (`Topics`)

`inverse-problems` · `tomography` · `total-variation` · `chambolle-pock` · `radon-transform` · `image-reconstruction` · `morozov`

## 4. Predloženi opis prvog commita

**Title**: `Add TV-regularized tomography reconstruction`

**Description**:

```text
- Implement nonnegative anisotropic TV reconstruction with Chambolle–Pock.
- Select lambda via Morozov's discrepancy principle (lambda ≈ 0.32).
- Compare FBP, TV and Tikhonov reconstructions.
- Document experiment, dependencies, data requirements and evaluation limits.
- Remove environment-specific paths and notebook drafting notes.
```

## 5. Prije javne objave

- Provjeri smiješ li objaviti izvorne podatke (nisu uključeni u ovaj paket).
- Rezultati na slikama i brojevi u README-u odnose se na izvorni eksperiment.
- Pokretanje cijele bilježnice zahtijeva `VjezbeTomografija_sinteticki.zip` koji nije bio među priloženim datotekama.
- Nakon dodavanja izvorne arhive pokreni **Run All** i provjeri reproduciraju li se rezultati.
